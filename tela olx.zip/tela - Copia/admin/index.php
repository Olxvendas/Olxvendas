<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de Administração</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #000;
            background-image: linear-gradient(135deg, #003366, #336699);
            background-size: cover;
            color: #fff;
            font-family: Arial, sans-serif;
        }

        .container {
            text-align: center;
            padding-top: 50px;
        }

        .botao {
            display: inline-block;
            padding: 15px 30px;
            font-size: 18px;
            font-weight: bold;
            text-transform: uppercase;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 10px;
            transition: all 0.3s ease;
            background-color: #4CAF50;
            color: #fff;
        }

        .botao:hover {
            background-color: #45a049;
        }

        .botao.infos {
            background-color: #008CBA;
        }

        .botao.infos:hover {
            background-color: #0073e6;
        }

        .botao.cadastrar {
            background-color: #f44336;
        }

        .botao.cadastrar:hover {
            background-color: #e53935;
        }

        .botao.pix {
            background-color: #FFD700;
        }

        .botao.pix:hover {
            background-color: #FFC107;
        }

        .criador {
            font-size: 14px;
            position: absolute;
            bottom: 10px;
            left: 10px;
            color: #fff;
        }

        .destaque {
            font-size: 18px;
            font-weight: bold;
            color: #FFD700;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Painel de Administração</h1>
    <button class="botao infos" onclick="window.location.href='../endereco/infos.txt'">Infos</button>
    <button class="botao cadastrar" onclick="window.location.href='../config.php'">Cadastrar Produto</button>
    <button class="botao pix" onclick="window.location.href='../pagamento/config.php'">Pix</button>
</div>

<div class="criador">Criado por <span class="destaque">Luiz Lemmer</span> - Zap: <span class="destaque">11-91089-3438</span></div>

</body>
</html>
