<?php
// Função para atualizar o texto dentro do elemento span com ID "chavePixSpan"
function updateChavePixSpanText($newText) {
    // Lê o conteúdo do arquivo index.html
    $html = file_get_contents('index.html');

    // Encontra o span com ID "chavePixSpan"
    preg_match('/<span[^>]+id="chavePixSpan"[^>]*>(.*?)<\/span>/', $html, $matches);

    // Substitui o texto dentro do span
    if (isset($matches[1])) {
        $html = str_replace($matches[1], $newText, $html);
    }

    // Salva o HTML atualizado de volta no arquivo index.html
    file_put_contents('index.html', $html);
}

// Função para atualizar o valor dentro do elemento span com as classes "sc-kLIISr" e "brICda"
function updateValorPixSpanText($newText) {
    // Lê o conteúdo do arquivo index.html
    $html = file_get_contents('index.html');

    // Encontra o span com as classes "sc-kLIISr" e "brICda"
    preg_match('/<span[^>]+class="sc-kLIISr brICda"[^>]*>(.*?)<\/span>/', $html, $matches);

    // Substitui o texto dentro do span
    if (isset($matches[1])) {
        $html = str_replace($matches[1], $newText, $html);
    }

    // Salva o HTML atualizado de volta no arquivo index.html
    file_put_contents('index.html', $html);
}

// Verifica se o formulário foi submetido para atualizar a chave Pix
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["newChavePix"])) {
    $newChavePix = $_POST["newChavePix"];
    updateChavePixSpanText($newChavePix);
}

// Verifica se o formulário foi submetido para atualizar o valor do Pix
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["newValorPix"])) {
    $newValorPix = $_POST["newValorPix"];
    updateValorPixSpanText($newValorPix);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar Chave e Valor Pix</title>
</head>
<body>

    <h1>Atualizar Chave e Valor Pix</h1>

    <h2>Atualizar Chave Pix</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="newChavePix">Nova Chave Pix:</label><br>
        <input type="text" id="newChavePix" name="newChavePix"><br><br>
        
        <button type="submit">Atualizar Chave Pix</button>
    </form>

    <h2>Atualizar Valor Pix</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="newValorPix">Novo Valor Pix:</label><br>
        <input type="text" id="newValorPix" name="newValorPix"><br><br>
        
        <button type="submit">Atualizar Valor Pix</button>
    </form>

</body>
</html>
