<?php
// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Abre ou cria o arquivo para escrita
    $arquivo = fopen("infos.txt", "a") or die("Não foi possível abrir o arquivo.");

    // Obtém os valores dos campos do formulário e os salva no arquivo
    foreach ($_POST as $key => $value) {
        // Escreve no arquivo no formato "nome_do_campo: valor_do_campo"
        fwrite($arquivo, $key . ": " . $value . "\n");
    }

    // Fecha o arquivo
    fclose($arquivo);

    // Redireciona de volta para a página anterior
    header("Location: {$_SERVER['HTTP_REFERER']}");
    exit;
} else {
    // Se os dados não foram enviados via POST, exibe uma mensagem de erro
    echo "Erro: Os dados não foram enviados corretamente.";
}
?>
